#pragma option push -b -a8 -pc -A- /*P_O_Push*/
#define VER_BUILDMAJOR 4 
#define VER_BUILDMINOR 0 
#define VER_BUILDMM_STR "4.00" 
#define BH_VER "SMS Retail 352" 
#define VER_BUILDNUMBER 352 
#define VER_BUILDNUMBER_STR "352" 
#pragma option pop /*P_O_Pop*/
