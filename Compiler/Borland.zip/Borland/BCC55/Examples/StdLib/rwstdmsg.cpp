#include "stlexam.h"
#pragma hdrstop
#include "rwstdmsg.h"
int _rw_messages_version()
{
   return _RW_MSG_START;
}